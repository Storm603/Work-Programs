﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Change
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write(@"Insert a number or stop the program with the keyword 'stop': ");
            string input = Console.ReadLine();

            while (input != "stop")
            {
                Dictionary<int, int> numbers = new Dictionary<int, int>()
                {
                    {1, 0},
                    {2, 0},
                    {5, 0},
                    {10, 0},
                    {20, 0}
                };

                int total = int.Parse(input);

                if (total <= 0)
                {
                    Console.WriteLine("Numbers needs to be a number bigger than 0 or a non-negative number!");
                    Console.Write("Insert a number: ");
                    input = Console.ReadLine();
                    continue;
                }
                if (total > 200)
                {
                    Console.WriteLine("Number needs to be a number lower than 200!");
                    Console.Write("Insert a number: ");
                    input = Console.ReadLine();
                    continue;
                }

                if (total < 10)
                {
                    SubtractingBanknotes(ref numbers, total);
                }
                if (total >= 10)
                {
                    numbers[1] += 1;
                    numbers[2] += 2;
                    numbers[5] += 1;

                    total -= 10;

                    SubtractingBanknotes(ref numbers, total);
                }

                foreach (KeyValuePair<int, int> keyValuePair in numbers)
                {
                    Console.WriteLine($"Banknote value {keyValuePair.Key} lv - Banknote count {keyValuePair.Value}");
                }
                Console.WriteLine();

                Console.Write("Insert a number: ");
                input = Console.ReadLine();
            }

            Console.WriteLine("Program stopped.");
        }

        public static void SubtractingBanknotes(ref Dictionary<int, int> numbers, int lastNum)
        {
            int constantLastNum = lastNum;

            int getLastNumber = lastNum % 10;
            int numberNeededToDivide = lastNum - getLastNumber;

            int banknoteBorder = numberNeededToDivide / 3;
            bool flag = false;

            for (int i = numbers.Count - 1; i >= 0; i--)
            {
                if (!flag && banknoteBorder >= lastNum && constantLastNum > 20)
                {
                    i--;
                    flag = true;
                }

                if (numbers.ElementAt(i).Key <= lastNum)
                {
                    lastNum -= numbers.ElementAt(i).Key;
                    int num = numbers.ElementAt(i).Key;
                    numbers[num]++;
                    i++;
                }
            }
        }
    }
}
